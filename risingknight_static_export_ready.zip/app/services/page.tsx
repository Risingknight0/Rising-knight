
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function Services() {
  const services = [
    {
      icon: 'ri-building-line',
      title: 'Company Formation',
      description: 'Complete business registration and setup services in Oman',
      features: [
        'Business license application',
        'Trade name registration',
        'Legal documentation',
        'Government approvals',
        'Tax registration',
        'Bank account setup'
      ]
    },
    {
      icon: 'ri-team-line',
      title: 'Local Partnership',
      description: 'Connect with trusted local partners for business success',
      features: [
        'Partner identification',
        'Due diligence support',
        'Legal agreement drafting',
        'Partnership structuring',
        'Ongoing relationship management',
        'Dispute resolution'
      ]
    },
    {
      icon: 'ri-lightbulb-line',
      title: 'Business Strategy',
      description: 'Strategic consulting for market entry and growth',
      features: [
        'Market analysis',
        'Business planning',
        'Financial projections',
        'Risk assessment',
        'Growth strategies',
        'Competitive analysis'
      ]
    },
    {
      icon: 'ri-palette-line',
      title: 'Brand Development',
      description: 'Complete branding and visual identity services',
      features: [
        'Logo design',
        'Brand guidelines',
        'Marketing materials',
        'Website development',
        'Social media setup',
        'Brand positioning'
      ]
    },
    {
      icon: 'ri-layout-line',
      title: 'Design Services',
      description: 'Professional design for digital and physical spaces',
      features: [
        'Office space design',
        'Retail fitout',
        'UX/UI design',
        'Interior consultation',
        'Space planning',
        'Design implementation'
      ]
    },
    {
      icon: 'ri-global-line',
      title: 'Digital Solutions',
      description: 'Comprehensive digital presence and marketing setup',
      features: [
        'Website development',
        'E-commerce solutions',
        'Digital marketing',
        'SEO optimization',
        'Social media management',
        'Analytics setup'
      ]
    }
  ];

  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-r from-black to-gray-800">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl font-bold text-white mb-6">Our Services</h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Comprehensive business solutions designed to help you establish, grow, and succeed in the Omani market.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto">
            <div className="grid md:grid-cols-2 gap-12">
              {services.map((service, index) => (
                <div key={index} className="bg-gray-50 rounded-2xl p-8 hover:shadow-lg transition-shadow">
                  <div className="flex items-start space-x-6">
                    <div className="w-16 h-16 bg-yellow-500 rounded-xl flex items-center justify-center">
                      <i className={`${service.icon} text-white text-2xl`}></i>
                    </div>
                    <div className="flex-1">
                      <h3 className="text-2xl font-bold text-black mb-3">{service.title}</h3>
                      <p className="text-gray-600 mb-6">{service.description}</p>
                      <ul className="space-y-2">
                        {service.features.map((feature, featureIndex) => (
                          <li key={featureIndex} className="flex items-center space-x-3">
                            <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                            <span className="text-gray-700">{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-black mb-4">Our Process</h2>
              <p className="text-gray-600 text-lg max-w-3xl mx-auto">
                We follow a structured approach to ensure your business setup is smooth and successful.
              </p>
            </div>
            
            <div className="grid md:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-white text-2xl font-bold">1</span>
                </div>
                <h3 className="text-xl font-bold text-black mb-3">Consultation</h3>
                <p className="text-gray-600">
                  Initial meeting to understand your business needs and objectives.
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-white text-2xl font-bold">2</span>
                </div>
                <h3 className="text-xl font-bold text-black mb-3">Planning</h3>
                <p className="text-gray-600">
                  Develop a comprehensive strategy and timeline for your business setup.
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-white text-2xl font-bold">3</span>
                </div>
                <h3 className="text-xl font-bold text-black mb-3">Implementation</h3>
                <p className="text-gray-600">
                  Execute the plan with our expert team handling all the details.
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-white text-2xl font-bold">4</span>
                </div>
                <h3 className="text-xl font-bold text-black mb-3">Launch</h3>
                <p className="text-gray-600">
                  Support your business launch and provide ongoing assistance.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-black">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl font-bold text-white mb-6">Ready to Start Your Business?</h2>
            <p className="text-xl text-gray-300 mb-8">
              Let's discuss how we can help you establish and grow your business in Oman.
            </p>
            <button className="bg-yellow-500 text-black px-8 py-4 rounded-full font-bold text-lg hover:bg-yellow-400 hover:scale-105 hover:shadow-xl transition-all duration-300 transform whitespace-nowrap cursor-pointer">
              Get Started Today
            </button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
