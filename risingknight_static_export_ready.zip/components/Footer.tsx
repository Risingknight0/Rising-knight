
'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-black text-white py-16">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            <div className="lg:col-span-2">
              <Link href="/" className="flex items-center space-x-3 mb-6">
                <div className="w-10 h-10 flex items-center justify-center">
                  <img 
                    src="https://static.readdy.ai/image/5a72743a1f00395da77dac9fb6789721/cfe452e7cdf3d043ea9cdc292947bd98.png"
                    alt="Rising Knight Logo"
                    className="w-full h-full object-contain"
                  />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white">
                    RISING KNIGHT
                  </h3>
                  <p className="text-gray-400 text-sm -mt-1">Consultancy Services & Company Formation</p>
                </div>
              </Link>
              <p className="text-gray-300 mb-6 max-w-md">
                We look forward to building your success in Oman. Your trusted partner for strategic business growth and company formation.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-yellow-600 hover:scale-110 hover:shadow-lg transition-all duration-300 transform cursor-pointer">
                  <i className="ri-linkedin-fill text-white"></i>
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-yellow-600 hover:scale-110 hover:shadow-lg transition-all duration-300 transform cursor-pointer">
                  <i className="ri-instagram-fill text-white"></i>
                </a>
              </div>
            </div>
            
            <div>
              <h4 className="text-lg font-bold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><Link href="/" className="text-gray-300 hover:text-white transition-colors">Home</Link></li>
                <li><Link href="/about" className="text-gray-300 hover:text-white transition-colors">About</Link></li>
                <li><Link href="/services" className="text-gray-300 hover:text-white transition-colors">Services</Link></li>
                <li><Link href="/contact" className="text-gray-300 hover:text-white transition-colors">Contact</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-bold mb-4">Contact Info</h4>
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <i className="ri-map-pin-line text-yellow-500 mt-1"></i>
                  <span className="text-gray-300">123 Business St., Muscat, Oman</span>
                </div>
                <div className="flex items-center space-x-3">
                  <i className="ri-phone-line text-yellow-500"></i>
                  <span className="text-gray-300">+968 77110840</span>
                </div>
                <div className="flex items-center space-x-3">
                  <i className="ri-mail-line text-yellow-500"></i>
                  <span className="text-gray-300">info@risingknight@gmail.com</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 pt-8 text-center">
            <p className="text-gray-400">
              2024 Rising Knight Consultancy. All rights reserved. | Building your success in Oman.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
