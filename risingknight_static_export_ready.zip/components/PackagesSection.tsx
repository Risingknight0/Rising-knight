
'use client';

export default function PackagesSection() {
  const packages = [
    {
      title: 'Foundation Support',
      subtitle: 'From idea to readiness.',
      description: 'Perfect for early-stage founders who need guidance and support to develop their business concept.',
      price: 'Starting from OMR 500',
      features: [
        'Legal advice and consultation',
        'Business mentoring sessions',
        'Comprehensive business planning',
        'Market research and analysis',
        'Regulatory compliance guidance',
        'Strategic roadmap development'
      ],
      color: 'bg-gray-50 border-gray-200',
      buttonColor: 'bg-black hover:bg-gray-800'
    },
    {
      title: 'Launch & Market Entry',
      subtitle: 'From registration to recognition.',
      description: 'Ideal for launch-ready entrepreneurs who need complete setup and market entry support.',
      price: 'Starting from OMR 1,500',
      features: [
        'Complete business registration',
        'Professional branding package',
        'Go-to-market strategy',
        'Digital presence setup',
        'Marketing materials creation',
        'Launch campaign management'
      ],
      color: 'bg-yellow-50 border-yellow-200',
      buttonColor: 'bg-yellow-600 hover:bg-yellow-700',
      popular: true
    },
    {
      title: 'Turnkey Business Build',
      subtitle: 'From vision to a business that runs.',
      description: 'Complete solution for investors who want a fully operational business with minimal involvement.',
      price: 'Starting from OMR 5,000',
      features: [
        'Premium location sourcing',
        'Full compliance management',
        'Complete design and fitout',
        'Professional website development',
        'Staff recruitment support',
        'Operational launch support'
      ],
      color: 'bg-gray-50 border-gray-200',
      buttonColor: 'bg-black hover:bg-gray-800'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-black mb-4">Business Packages</h2>
            <p className="text-gray-600 text-lg max-w-3xl mx-auto">
              Choose the perfect package for your business stage. Each package is designed to provide comprehensive support tailored to your specific needs.
            </p>
          </div>
          
          <div className="grid lg:grid-cols-3 gap-8">
            {packages.map((pkg, index) => (
              <div key={index} className={`rounded-2xl p-8 border-2 ${pkg.color} relative ${pkg.popular ? 'scale-105' : ''}`}>
                {pkg.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-yellow-500 text-black px-4 py-2 rounded-full text-sm font-bold">
                      Most Popular
                    </span>
                  </div>
                )}
                
                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold text-black mb-2">{pkg.title}</h3>
                  <p className="text-gray-600 font-medium mb-4">{pkg.subtitle}</p>
                  <p className="text-gray-600 text-sm mb-6">{pkg.description}</p>
                  <div className="text-3xl font-bold text-black mb-6">{pkg.price}</div>
                </div>
                
                <ul className="space-y-4 mb-8">
                  {pkg.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start space-x-3">
                      <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center mt-0.5">
                        <i className="ri-check-line text-white text-sm"></i>
                      </div>
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <button className={`w-full ${pkg.buttonColor} text-white py-3 rounded-full font-bold hover:scale-105 hover:shadow-lg transition-all duration-300 transform whitespace-nowrap cursor-pointer`}>
                  Choose This Package
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
