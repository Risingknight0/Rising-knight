
'use client';

export default function CTASection() {
  return (
    <section 
      className="py-20 bg-cover bg-center relative"
      style={{
        backgroundImage: `url('https://readdy.ai/api/search-image?query=Elegant%20golden%20chess%20knight%20piece%20on%20dark%20black%20background%2C%20luxury%20business%20strategy%20concept%2C%20professional%20corporate%20setting%2C%20minimalist%20composition%2C%20sophisticated%20lighting%2C%20strategic%20planning%20symbolism%2C%20high-end%20business%20atmosphere%2C%20gold%20and%20black%20color%20scheme&width=1920&height=600&seq=cta1&orientation=landscape')`
      }}
    >
      <div className="absolute inset-0 bg-black/90"></div>
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 leading-tight">
            Every knight needs a strategy.<br />
            Every brand needs a path.
          </h2>
          <p className="text-xl text-gray-100 mb-8 max-w-3xl mx-auto">
            Choose your package and build your legacy. Let us help you navigate the Omani business landscape with strategic excellence and professional support.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-yellow-500 text-black px-8 py-4 rounded-full font-bold text-lg hover:bg-yellow-400 hover:scale-105 hover:shadow-xl transition-all duration-300 transform whitespace-nowrap cursor-pointer">
              Choose Your Package
            </button>
            <button className="border-2 border-white text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-white hover:text-black hover:scale-105 hover:shadow-xl transition-all duration-300 transform whitespace-nowrap cursor-pointer">
              Schedule Consultation
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
