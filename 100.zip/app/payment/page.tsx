
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { Suspense } from 'react';

function PaymentForm() {
  const searchParams = useSearchParams();
  const [selectedPackage, setSelectedPackage] = useState('');
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    company: '',
    address: '',
    city: '',
    postalCode: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardName: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState('');

  const packages = {
    foundation: {
      name: 'Foundation Support',
      price: 'OMR 500',
      amount: 500,
      description: 'From idea to readiness'
    },
    launch: {
      name: 'Launch & Market Entry',
      price: 'OMR 1,500',
      amount: 1500,
      description: 'From registration to recognition'
    },
    turnkey: {
      name: 'Turnkey Business Build',
      price: 'OMR 5,000',
      amount: 5000,
      description: 'From vision to a business that runs'
    }
  };

  useEffect(() => {
    const packageParam = searchParams.get('package');
    if (packageParam && packages[packageParam as keyof typeof packages]) {
      setSelectedPackage(packageParam);
    }
  }, [searchParams]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const paymentData = {
        ...formData,
        package: selectedPackage,
        amount: packages[selectedPackage as keyof typeof packages]?.amount || 0
      };
      
      const response = await fetch('/api/payment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams(paymentData).toString(),
      });
      
      if (response.ok) {
        setSubmitStatus('Payment submitted successfully! We will process your order and contact you within 24 hours.');
        setFormData({
          firstName: '',
          lastName: '',
          email: '',
          phone: '',
          company: '',
          address: '',
          city: '',
          postalCode: '',
          cardNumber: '',
          expiryDate: '',
          cvv: '',
          cardName: ''
        });
      } else {
        setSubmitStatus('Payment failed. Please try again or contact support.');
      }
    } catch (error) {
      setSubmitStatus('Payment failed. Please try again or contact support.');
    }
    
    setIsSubmitting(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const currentPackage = packages[selectedPackage as keyof typeof packages];

  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-r from-black to-gray-800">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl font-bold text-white mb-6">Secure Payment</h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Complete your order securely. Your payment information is protected with industry-standard encryption.
            </p>
          </div>
        </div>
      </section>

      {/* Payment Form */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <div className="grid lg:grid-cols-2 gap-12">
              {/* Order Summary */}
              <div>
                <h2 className="text-3xl font-bold text-black mb-8">Order Summary</h2>
                
                {/* Package Selection */}
                <div className="mb-8">
                  <label className="block text-gray-700 text-sm font-medium mb-4">
                    Select Package
                  </label>
                  <div className="relative">
                    <select
                      value={selectedPackage}
                      onChange={(e) => setSelectedPackage(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent text-sm pr-8 appearance-none"
                      required
                    >
                      <option value="">Choose a package</option>
                      <option value="foundation">Foundation Support - OMR 500</option>
                      <option value="launch">Launch & Market Entry - OMR 1,500</option>
                      <option value="turnkey">Turnkey Business Build - OMR 5,000</option>
                    </select>
                    <div className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 flex items-center justify-center">
                      <i className="ri-arrow-down-s-line text-gray-400"></i>
                    </div>
                  </div>
                </div>

                {/* Package Details */}
                {currentPackage && (
                  <div className="bg-gray-50 rounded-lg p-6 mb-8">
                    <h3 className="text-xl font-bold text-black mb-2">{currentPackage.name}</h3>
                    <p className="text-gray-600 mb-4">{currentPackage.description}</p>
                    <div className="flex justify-between items-center">
                      <span className="text-lg font-medium text-gray-700">Total Amount:</span>
                      <span className="text-2xl font-bold text-black">{currentPackage.price}</span>
                    </div>
                  </div>
                )}

                {/* Security Features */}
                <div className="bg-green-50 rounded-lg p-6">
                  <h3 className="text-lg font-bold text-green-800 mb-4">Security Features</h3>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <i className="ri-shield-check-line text-green-600"></i>
                      <span className="text-green-700">SSL Encrypted Connection</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <i className="ri-lock-line text-green-600"></i>
                      <span className="text-green-700">Secure Payment Processing</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <i className="ri-shield-line text-green-600"></i>
                      <span className="text-green-700">Data Protection Guaranteed</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Payment Form */}
              <div>
                <h2 className="text-3xl font-bold text-black mb-8">Payment Details</h2>
                
                <form id="payment-form" onSubmit={handleSubmit} className="space-y-6">
                  {/* Personal Information */}
                  <div>
                    <h3 className="text-lg font-bold text-black mb-4">Personal Information</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-gray-700 text-sm font-medium mb-2">
                          First Name *
                        </label>
                        <input
                          type="text"
                          name="firstName"
                          value={formData.firstName}
                          onChange={handleChange}
                          required
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent text-sm"
                          placeholder="Enter first name"
                        />
                      </div>
                      <div>
                        <label className="block text-gray-700 text-sm font-medium mb-2">
                          Last Name *
                        </label>
                        <input
                          type="text"
                          name="lastName"
                          value={formData.lastName}
                          onChange={handleChange}
                          required
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent text-sm"
                          placeholder="Enter last name"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-sm font-medium mb-2">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent text-sm"
                        placeholder="Enter email"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 text-sm font-medium mb-2">
                        Phone Number *
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent text-sm"
                        placeholder="Enter phone"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-gray-700 text-sm font-medium mb-2">
                      Company Name
                    </label>
                    <input
                      type="text"
                      name="company"
                      value={formData.company}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent text-sm"
                      placeholder="Enter company name"
                    />
                  </div>

                  {/* Billing Address */}
                  <div>
                    <h3 className="text-lg font-bold text-black mb-4">Billing Address</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-gray-700 text-sm font-medium mb-2">
                          Address *
                        </label>
                        <input
                          type="text"
                          name="address"
                          value={formData.address}
                          onChange={handleChange}
                          required
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent text-sm"
                          placeholder="Enter address"
                        />
                      </div>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-gray-700 text-sm font-medium mb-2">
                            City *
                          </label>
                          <input
                            type="text"
                            name="city"
                            value={formData.city}
                            onChange={handleChange}
                            required
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent text-sm"
                            placeholder="Enter city"
                          />
                        </div>
                        <div>
                          <label className="block text-gray-700 text-sm font-medium mb-2">
                            Postal Code *
                          </label>
                          <input
                            type="text"
                            name="postalCode"
                            value={formData.postalCode}
                            onChange={handleChange}
                            required
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent text-sm"
                            placeholder="Enter postal code"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Payment Information */}
                  <div>
                    <h3 className="text-lg font-bold text-black mb-4">Payment Information</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-gray-700 text-sm font-medium mb-2">
                          Card Number *
                        </label>
                        <input
                          type="text"
                          name="cardNumber"
                          value={formData.cardNumber}
                          onChange={handleChange}
                          required
                          placeholder="1234 5678 9012 3456"
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent text-sm"
                        />
                      </div>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-gray-700 text-sm font-medium mb-2">
                            Expiry Date *
                          </label>
                          <input
                            type="text"
                            name="expiryDate"
                            value={formData.expiryDate}
                            onChange={handleChange}
                            required
                            placeholder="MM/YY"
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent text-sm"
                          />
                        </div>
                        <div>
                          <label className="block text-gray-700 text-sm font-medium mb-2">
                            CVV *
                          </label>
                          <input
                            type="text"
                            name="cvv"
                            value={formData.cvv}
                            onChange={handleChange}
                            required
                            placeholder="123"
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent text-sm"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-gray-700 text-sm font-medium mb-2">
                          Name on Card *
                        </label>
                        <input
                          type="text"
                          name="cardName"
                          value={formData.cardName}
                          onChange={handleChange}
                          required
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent text-sm"
                          placeholder="Enter name as on card"
                        />
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting || !selectedPackage}
                    className="w-full bg-yellow-500 text-black py-4 px-6 rounded-lg font-bold hover:bg-yellow-400 hover:scale-105 hover:shadow-lg transition-all duration-300 transform disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap cursor-pointer"
                  >
                    {isSubmitting ? 'Processing Payment...' : `Pay ${currentPackage?.price || 'Select Package'}`}
                  </button>
                  
                  {submitStatus && (
                    <div className={`p-4 rounded-lg ${submitStatus.includes('successfully') ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'}`}>
                      {submitStatus}
                    </div>
                  )}
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}

export default function Payment() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center">Loading...</div>}>
      <PaymentForm />
    </Suspense>
  );
}
