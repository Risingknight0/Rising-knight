
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function About() {
  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-r from-black to-gray-800">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl font-bold text-white mb-6">About Rising Knight</h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Your trusted partner for strategic business growth and company formation in Oman. We combine local expertise with global standards to help you succeed.
            </p>
          </div>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-4xl font-bold text-black mb-6">Our Story</h2>
                <p className="text-gray-600 text-lg leading-relaxed mb-6">
                  Founded with a vision to bridge the gap between international investors and the Omani market, Rising Knight has been instrumental in helping dozens of businesses establish and thrive in Oman.
                </p>
                <p className="text-gray-600 text-lg leading-relaxed mb-6">
                  We understand the unique challenges faced by expats and international investors when entering a new market. Our comprehensive approach combines legal expertise, strategic planning, and local market knowledge to ensure your success.
                </p>
              </div>
              <div>
                <img 
                  src="https://readdy.ai/api/search-image?query=Professional%20business%20team%20in%20modern%20Omani%20office%2C%20diverse%20group%20of%20consultants%20working%20together%2C%20strategic%20planning%20session%20with%20documents%20and%20laptops%2C%20elegant%20office%20environment%20in%20Muscat%2C%20teamwork%20and%20collaboration%2C%20modern%20corporate%20setting&width=600&height=400&seq=about1&orientation=landscape"
                  alt="Our team"
                  className="rounded-2xl shadow-xl w-full h-80 object-cover object-top"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-black mb-4">Our Values</h2>
              <p className="text-gray-600 text-lg max-w-3xl mx-auto">
                These core principles guide everything we do and ensure we deliver exceptional results for our clients.
              </p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-6">
                  <i className="ri-shield-check-line text-white text-2xl"></i>
                </div>
                <h3 className="text-2xl font-bold text-black mb-4">Integrity</h3>
                <p className="text-gray-600">
                  We maintain the highest ethical standards in all our business dealings and client relationships.
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-6">
                  <i className="ri-lightbulb-line text-white text-2xl"></i>
                </div>
                <h3 className="text-2xl font-bold text-black mb-4">Innovation</h3>
                <p className="text-gray-600">
                  We continuously evolve our services and approaches to meet the changing needs of our clients.
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-6">
                  <i className="ri-heart-line text-white text-2xl"></i>
                </div>
                <h3 className="text-2xl font-bold text-black mb-4">Excellence</h3>
                <p className="text-gray-600">
                  We strive for perfection in every project and go above and beyond to exceed expectations.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-black mb-4">Our Leadership Team</h2>
              <p className="text-gray-600 text-lg max-w-3xl mx-auto">
                Meet the experienced professionals who lead our mission to help businesses succeed in Oman.
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-12 justify-center">
              <div className="text-center">
                <h3 className="text-2xl font-bold text-black mb-2">Ali Mohamed</h3>
                <p className="text-yellow-600 mb-4 font-semibold">Founder & CEO</p>
                <p className="text-gray-600">
                  15+ years of experience in business development and strategic consulting in the GCC region.
                </p>
              </div>
              
              <div className="text-center">
                <h3 className="text-2xl font-bold text-black mb-2">Bogdan</h3>
                <p className="text-yellow-600 mb-4 font-semibold">Co-Founder</p>
                <p className="text-gray-600">
                  Expert in operational excellence and business process optimization with international experience.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
