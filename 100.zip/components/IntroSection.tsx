
'use client';

export default function IntroSection() {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="flex items-center space-x-4">
                <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                <span className="text-black font-semibold text-lg">Your local Omani partner</span>
              </div>
              <div className="flex items-center space-x-4">
                <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                <span className="text-black font-semibold text-lg">A to Z support</span>
              </div>
              <h2 className="text-4xl font-bold text-black leading-tight">
                We embody elegance, professionalism, and strategic excellence.
              </h2>
              <p className="text-gray-600 text-lg leading-relaxed">
                We support investors and expats to launch and grow businesses in Oman with full strategic support. From initial consultation to complete business setup, we provide comprehensive services tailored to your success in the Omani market.
              </p>
            </div>
            <div className="relative">
              <img 
                src="https://readdy.ai/api/search-image?query=Professional%20business%20meeting%20in%20modern%20Omani%20office%2C%20elegant%20businesspeople%20discussing%20strategy%2C%20golden%20chess%20knight%20on%20conference%20table%2C%20luxury%20corporate%20environment%2C%20Middle%20Eastern%20business%20culture%2C%20professional%20handshake%2C%20strategic%20planning%20documents%2C%20modern%20office%20interior%20in%20Muscat%20Oman&width=600&height=400&seq=intro1&orientation=landscape"
                alt="Professional business consultation"
                className="rounded-2xl shadow-xl w-full h-80 object-cover object-top"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
