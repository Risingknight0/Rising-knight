
'use client';

export default function ServicesSection() {
  const services = [
    {
      icon: 'ri-building-line',
      title: 'Company Setup',
      description: 'Complete business registration and legal setup services in Oman with full compliance support.'
    },
    {
      icon: 'ri-team-line',
      title: 'Local Partner Matching',
      description: 'Connect with trusted local partners to meet legal requirements and expand your network.'
    },
    {
      icon: 'ri-lightbulb-line',
      title: 'Business Consulting',
      description: 'Strategic guidance and expert advice to navigate the Omani business landscape successfully.'
    },
    {
      icon: 'ri-palette-line',
      title: 'Branding & Identity',
      description: 'Professional brand development and visual identity creation for market impact.'
    },
    {
      icon: 'ri-layout-line',
      title: 'UX & Space Design',
      description: 'Comprehensive design services for digital platforms and physical business spaces.'
    },
    {
      icon: 'ri-global-line',
      title: 'Digital Presence',
      description: 'Complete digital marketing setup including websites, social media, and online visibility.'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-black mb-4">Our Services</h2>
            <p className="text-gray-600 text-lg max-w-3xl mx-auto">
              We provide comprehensive business support services designed to help you succeed in the Omani market. From setup to growth, we're with you every step of the way.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="bg-white rounded-xl p-8 shadow-sm hover:shadow-md transition-shadow">
                <div className="w-12 h-12 bg-black rounded-lg flex items-center justify-center mb-6">
                  <i className={`${service.icon} text-white text-xl`}></i>
                </div>
                <h3 className="text-xl font-bold text-black mb-3">{service.title}</h3>
                <p className="text-gray-600 leading-relaxed">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
