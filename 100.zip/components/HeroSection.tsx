
'use client';

export default function HeroSection() {
  return (
    <section 
      className="min-h-screen flex items-center justify-center bg-cover bg-center relative"
      style={{
        backgroundImage: `url('https://static.readdy.ai/image/5a72743a1f00395da77dac9fb6789721/5f307c5a024f2176fae18f1bc637673d.jfif')`
      }}
    >
      <div className="absolute inset-0 bg-black/50"></div>
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6 leading-tight">
            Every knight needs a strategy.<br />
            Every brand needs a path.
          </h1>
          <p className="text-xl text-gray-100 mb-8 max-w-2xl">
            We support investors and expats to launch and grow businesses in Oman with full strategic support.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button className="bg-yellow-500 text-black px-8 py-4 rounded-full font-bold text-lg hover:bg-yellow-400 hover:scale-105 hover:shadow-xl transition-all duration-300 transform whitespace-nowrap cursor-pointer">
              Choose Your Package
            </button>
            <button className="border-2 border-white text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-white hover:text-black hover:scale-105 hover:shadow-xl transition-all duration-300 transform whitespace-nowrap cursor-pointer">
              Learn More
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
